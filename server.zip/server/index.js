import express from "express";
import bodyParser from 'body-parser';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import products from "./routes/products.js";
import shipping from "./routes/shipping.js"
import orders from './routes/orders.js';
import payments from './routes/payments.js';
import notifications from "./routes/notifications.js";
import sgMail from '@sendgrid/mail';
import me from "./routes/me.js";
import Stripe from "stripe";
import path from "path";

const app = express();
dotenv.config();

sgMail.setApiKey(process.env.SENDGRID_KEY);
export const stripe = Stripe(process.env.STRIPE_PRIVATE_KEY);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());

app.use('/orders', orders);
app.use('/payments', payments);
app.use('/products', products);
app.use('/shipping',shipping);
app.use('/notifications', notifications);
app.use('/me', me);

app.get('/', (req, res) => {
    res.status(200).json({
        team_name: "Curious Monkeys",
        dev_team: ["Baraa A.", "Eman S.", "Sary N.", "Youssef S."].sort()
    })
});

const PORT = process.env.PORT || 5000;

const mongooseOptions = {
    useNewUrlParser: true,
    useUnifiedTopology: true
}

// Serve React frontend
const __dirname = path.resolve();
app.use(express.static(path.join(__dirname, '../client/build')));

// Handle React routing, send index.html for any unknown route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/dist/index.html'));
});

// app.get(/^(?!\/orders|\/products|\/payments|\/shipping|\/notifications|\/me).*$/, (req, res) => {
//   res.sendFile(path.join(__dirname, "../client/build/index.html"));
// });


const handleServerStartup = () => {
    app.listen(PORT, () => console.log(`Server listening on port ${PORT}`))
}
console.log("process.env.CONNECTION_URL", process.env.CONNECTION_URL)
mongoose.connect(process.env.CONNECTION_URL, mongooseOptions, handleServerStartup)
const db = mongoose.connection;
db.on('error', (error) => console.error('MongoDB connection error:', error));
db.once('open', () => console.log('Connected to MongoDB database.'));
export default app